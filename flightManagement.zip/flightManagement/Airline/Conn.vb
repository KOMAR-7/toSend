﻿Imports System.Data.OleDb
Module Conn
    Public cnn As New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Plane.mdb")
    Public Sub copen()
        If cnn.State <> ConnectionState.Open Then
            cnn.Open()
        End If
    End Sub
    Public Sub cclose()
        cnn.Close()
    End Sub

End Module
