# README #

This is SIMPLE Airline Reservation System in VB.NET - some practice project